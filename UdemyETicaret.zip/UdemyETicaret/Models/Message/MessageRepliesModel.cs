﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UdemyETicaret.Models.Message
{
    public class MessageRepliesModel
    {
        public List<DB.MessageReplies> MReplies { get; set; }
        public int ToMemberId { get; internal set; }
    }
}