﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UdemyETicaret.Models
{
    public enum MemberTypeEnum : int
    {
        Customer = 0,
        Editor = 8,
        Admin = 10
    }
}