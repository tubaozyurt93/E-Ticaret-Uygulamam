﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UdemyETicaret.Models.Account
{
    public class LoginModels
    {
        public DB.Members Member { get; set; }
    }
}