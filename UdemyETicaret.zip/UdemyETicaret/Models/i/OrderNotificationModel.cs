﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace UdemyETicaret.Models.i
{
    public class OrderNotificationModel
    {
        public string OrderId { get; set; }
        public string OrderDescription { get; set; }
    }
}